from django.shortcuts import render, redirect
from django.http import JsonResponse
from random import randint
from .models import Display_Info,Display_Info_lc

def home(request):
    return render(request, "home.html")


def fform(request):
    if request.method == "POST":
        name1 = request.POST.get("name1", 0)
        name2 = request.POST.get("name2", 0)
        t = Display_Info(name1=name1, name2=name2)
        t.save()

        # print(name1, name2)
        def remove_match_char(list1, list2):
            for i in range(len(list1)):
                for j in range(len(list2)):

                    if list1[i] == list2[j]:
                        c = list1[i]

                        list1.remove(c)
                        list2.remove(c)

                        list3 = list1 + ["*"] + list2

                        return [list3, True]

            list3 = list1 + ["*"] + list2
            return [list3, False]

        # if __name__ == "__main__":

        # name1 = request.POST.get("name1", 0)
        name1 = name1.replace(" ", "")
        name1 = name1.lower()
        name1_list = list(name1)
        print(name1)

        # name2 = request.POST.get("name2", 0)
        name2 = name2.lower()
        name2 = name2.replace(" ", "")
        name2_list = list(name2)
        print(name2)

        proceed = True

        while proceed:
            ret_list = remove_match_char(name1_list, name2_list)

            con_list = ret_list[0]

            proceed = ret_list[1]

            star_index = con_list.index("*")

            name1_list = con_list[:star_index]

            name2_list = con_list[star_index + 1:]

        count = len(name1_list) + len(name2_list)
        result = ["Friends", "Love", "Affection", "Marriage", "Enemy", "Siblings"]
        while len(result) > 1:

            split_index = count % len(result) - 1

            if split_index >= 0:

                right = result[split_index + 1:]
                left = result[:split_index]

                result = right + left

            else:
                result = result[: len(result) - 1]
        print(result[0])
        redirect_dict = {
            "Friends": "friends",
            "Love": "loves",
            "Affection": "affections",
            "Marriage": "marriages",
            "Enemy": "enemies",
            "Siblings": "siblings",
        }

        return JsonResponse({"success": True, "URL": redirect_dict[result[0]]})

    return render(request, "fform.html")


def icalci(request):
    global percent
    if request.method == "POST":
        name1 = request.POST.get("name1", 0)
        name2 = request.POST.get("name2", 0)
        q= Display_Info_lc(name1=name1, name2=name2)
        q.save()

        def remove_match_char(list1, list2):
            for i in range(len(list1)):
                for j in range(len(list2)):

                    if list1[i] == list2[j]:
                        c = list1[i]

                        list1.remove(c)
                        list2.remove(c)

                        list3 = list1 + ["*"] + list2

                        return [list3, True]

            list3 = list1 + ["*"] + list2
            return [list3, False]

        # if __name__ == "__main__":

        #name1 = request.POST.get("name1", 0)
        name1 = name1.replace(" ", "")
        name1 = name1.lower()
        name1_list = list(name1)
        print(name1)

        #name2 = request.POST.get("name2", 0)
        name2 = name2.lower()
        name2 = name2.replace(" ", "")
        name2_list = list(name2)
        print(name2)

        proceed = True

        while proceed:
            ret_list = remove_match_char(name1_list, name2_list)

            con_list = ret_list[0]

            proceed = ret_list[1]

            star_index = con_list.index("*")

            name1_list = con_list[:star_index]

            name2_list = con_list[star_index + 1:]

        count = len(name1_list) + len(name2_list)
        result = ["Friends", "Love", "Affection", "Marriage", "Enemy", "Siblings"]
        while len(result) > 1:

            split_index = count % len(result) - 1

            if split_index >= 0:

                right = result[split_index + 1:]
                left = result[:split_index]

                result = right + left

            else:
                result = result[: len(result) - 1]
        print(result[0])

        if result[0] == "Friends":

            percent = randint(60, 70)

        elif result[0] == "Love":

            percent = randint(80, 90)

        elif result[0] == "Marriage":

            percent = randint(90, 100)

        elif result[0] == "Affection":

            percent = randint(70, 80)

        elif result[0] == "Enemy":
            percent = randint(20, 50)

        elif result[0] == "Siblings":
            percent = randint(50, 60)

        return JsonResponse({"success": True, "URL": "/percent/", "percent": percent})

    return render(request, "icalci.html")


def friends(request):
    return render(request, "friends.html")


def loves(request):
    return render(request, "loves.html")


def affections(request):
    return render(request, "affections.html")


def marriages(request):
    return render(request, "marriages.html")


def enemies(request):
    return render(request, "enemies.html")


def siblings(request):
    return render(request, "siblings.html")


def percent(request):
    percent = request.GET.get("p", 0) or 0
    return render(request, "percent.html", context={"percent": percent})

# Create your views here.
