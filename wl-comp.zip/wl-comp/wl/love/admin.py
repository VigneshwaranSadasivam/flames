from django.contrib import admin
from .models import Display_Info




class Display(admin.ModelAdmin):
    list_display = ['name1', 'name2']


# to view model in admin Panel we need to register here
admin.site.register(Display_Info, Display)







