const back = document.getElementById("back");
const name1 = document.getElementById("Name1");
const name2 = document.getElementById("Name2");
const Submit_Btn = document.getElementById("submit_f");
const alert_container = document.getElementById("alert_f")

function Redirect(e) {
    window.location.replace("/home");
}
    

const alertUser = (CODE,elem, msg) => {
    let alertContent = "";
    switch (CODE) {
        case 0:
            alertContent = '<div class="alert alert-danger" role="alert"><p>' + msg + '</p></div>';
            break;
        case 1:
            alertContent = '<div class="alert alert-success" role="alert"><p>' + msg + '</p></div>';
            break;
        default:
            alertContent = '<div class="alert alert-warning" role="alert"><p>' + msg + '</p></div>';
            break;
    }
    elem.innerHTML = alertContent;
};

const Submit_Handler = (e) => {
    const name1 = Name1.value;
    const name2 = Name2.value;
    if (name1 === '' || name2 === '') {
        alertUser(0, alert_container, 'name1 or name 2 is empty');
    }
    else {
        let formData = new FormData();
        formData.append("name1", name1);
        formData.append("name2", name2);
        formData.append("csrfmiddlewaretoken", document.getElementsByName("csrfmiddlewaretoken")[0].value)

        let data = new URLSearchParams(formData);

        fetch('/icalci/', {
            method: 'POST',
            body:data
        }).then(response => response.json()).then(data => {

        if(data.success===true){
        console.log(data);
            window.location.replace("/percent?p=" + data.percent);
        }
        }).catch(err=>console.log(err));

    }
};

Submit_Btn.addEventListener('click', Submit_Handler)
back.addEventListener('click', Redirect)
