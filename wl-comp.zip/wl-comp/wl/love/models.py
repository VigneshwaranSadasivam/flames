from django.db import models


class Display_Info(models.Model):
    # colunms
    name1 = models.CharField(max_length=20)
    name2 = models.CharField(max_length=20)

class Display_Info_lc(models.Model):
    name1 = models.CharField(max_length=20)
    name2 = models.CharField(max_length=20)

